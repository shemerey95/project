//  Функция валидации поля "Номер карты":
var cardInputs = document.querySelectorAll('.box_number input');

var mas = [false, false, false, false];
for (var i = 0; i < cardInputs.length; i++) {
    cardInputs[i].i = i;
    // Вешаем обработчик на событие ввода:
    cardInputs[i].addEventListener('input', function () {
        // Создаём переменную и сохраняем в неё экземпляр класса регулярных выражений
        var reg = new RegExp('^\\d+$');
        if (reg.test(this.value) && this.value.length == 4) {
            this.classList.remove('notValid');
            mas[this.i] = true;
        } else  {
            this.classList.add('notValid');
            mas[this.i] = false;
        }
        checkForm();
    })
}


//  Функция валидации поля "Держатель карты":
var ownerCard = false;

document.getElementById('ownerCard').addEventListener('input', function() {
    var leg = new RegExp('^[a-zA-Z]+$');
    if (leg.test(this.value) && this.value.length >= 4) {
        this.classList.remove('notValid');
        ownerCard = true;
    } else {
        this.classList.add('notValid');
        ownerCard  = false;
    }
    checkForm();
})


//  Функция валидации поля "Держатель карты":
var cvv = false;

document.querySelector('.code input').addEventListener('input', function() {
    var zeg = new RegExp('^\\d+$');
    if (zeg.test(this.value) && this.value.length == 3) {
        this.classList.remove('notValid');
        cvv = true;
    } else {
        this.classList.add('notValid');
        cvv  = false;
    }
    checkForm();
})


//  Функция для разблокировки кнопки "Отправить":
function checkForm() { 
    var result = false;
    if (mas.every(function(element) {
        return element === true;
    }) && ownerCard && cvv) result = true;
        else result = false;
    if (result == true) {
         document.querySelector('.button').disabled = false; 
         document.querySelector('.button').classList.add('opacity');
    }
    else {
        document.querySelector('.button').disabled = true;
        document.querySelector('.button').classList.remove('opacity');
    }
    console.log(result);
}



//  Функция для работы кнопки "Меню" на мобильных устройствах и планшетах:
document.querySelector('.menuButt').addEventListener('click', function () {
    document.querySelector('#leftCol').classList.toggle('visible');
})
